package com.redbus.testcases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.redbus.pageobject.HomePage;

import Utils.BrowserDriver;

public class RedBus {
	
	static HomePage homepage;
	
	@BeforeSuite
	public void setupSuite() {
		homepage=new HomePage();
	}

	
	@Test
	public void verifyLogin() throws Throwable {
		homepage.loadRedBus();
		homepage.searchBus();
		homepage.selectDateCal();
		homepage.viewseats();
		homepage.booktickets();
		homepage.ticketprice();
}
	
	
	@AfterTest
	public void tearDown() {
		 BrowserDriver.getCurrentDriver().close();
	}
	
	
}
